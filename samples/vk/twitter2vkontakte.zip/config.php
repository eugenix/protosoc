<?
$twitterUser = 'pupkin';
$twitterPassword = 'temp';

$vkontakteEmail = 'pupkin@yandex.ru';
$vkontaktePassword = 'temp';
?>